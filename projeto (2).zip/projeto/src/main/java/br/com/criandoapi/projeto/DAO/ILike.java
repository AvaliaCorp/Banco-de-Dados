package br.com.criandoapi.projeto.DAO;

import org.springframework.data.repository.CrudRepository;

import br.com.criandoapi.projeto.model.Like;


public interface ILike  extends CrudRepository<Like, String>{

}


