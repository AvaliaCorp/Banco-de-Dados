package br.com.criandoapi.projeto.DAO;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class IUsuarioTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
