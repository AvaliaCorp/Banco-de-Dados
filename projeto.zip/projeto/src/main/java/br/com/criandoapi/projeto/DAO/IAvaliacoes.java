package br.com.criandoapi.projeto.DAO;

import org.springframework.data.repository.CrudRepository;

import br.com.criandoapi.projeto.model.Avaliacoes;

public interface IAvaliacoes extends CrudRepository<Avaliacoes, Integer> {

}
